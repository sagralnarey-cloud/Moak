import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  "projectId": "goalpulse-tagzq",
  "appId": "1:433263496470:web:b85d0576826f277c48d437",
  "storageBucket": "goalpulse-tagzq.firebasestorage.app",
  "apiKey": "AIzaSyB-EHawYivjkOORAsDpZQVaOwOuFLf1pqs",
  "authDomain": "goalpulse-tagzq.firebaseapp.com",
  "messagingSenderId": "433263496470"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
