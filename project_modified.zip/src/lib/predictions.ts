
"use server";

import { doc, setDoc, serverTimestamp, getDoc, updateDoc, collection, query, where, getDocs, writeBatch, increment, orderBy, limit } from 'firebase/firestore';
import { db } from './firebase';
import type { Prediction, UserProfile, Match } from '@/types';
import { getPredictedMatches } from './api';

export async function submitPrediction(
    userId: string, 
    matchId: number, 
    homeScore: number, 
    awayScore: number
): Promise<{success: boolean, message: string}> {
  if (!userId) {
    return { success: false, message: "User not authenticated." };
  }
  try {
    const predictionId = `${userId}_${matchId}`;
    const predictionRef = doc(db, 'predictions', predictionId);

    const prediction: Prediction = {
        id: predictionId,
        userId,
        matchId,
        homeScore,
        awayScore,
        status: 'pending',
        timestamp: serverTimestamp(),
    };

    await setDoc(predictionRef, prediction, { merge: true });
    return { success: true, message: "Prediction submitted successfully!" };
  } catch (error) {
    console.error("Error submitting prediction:", error);
    return { success: false, message: "Failed to submit prediction." };
  }
}

export async function getUserPredictions(userId: string, fetchMatches: boolean = false): Promise<Prediction[] | Match[]> {
    if (!userId) return [];

    const predictionsRef = collection(db, 'predictions');
    const q = query(predictionsRef, where('userId', '==', userId), orderBy('timestamp', 'desc'));
    
    const querySnapshot = await getDocs(q);
    const predictions = querySnapshot.docs.map(doc => doc.data() as Prediction);

    if (fetchMatches) {
        const matchIds = predictions.map(p => p.matchId);
        if (matchIds.length === 0) return [];
        
        const matches = await getPredictedMatches(matchIds);
        
        // Combine prediction data with match data
        return matches.map(match => ({
            ...match,
            userPrediction: predictions.find(p => p.matchId === match.id)
        })).sort((a,b) => (b.userPrediction?.timestamp?.toDate() ?? 0) - (a.userPrediction?.timestamp?.toDate() ?? 0));
    }

    return predictions;
}

export async function getLeaderboard(): Promise<UserProfile[]> {
    const usersRef = collection(db, 'users');
    const q = query(usersRef, orderBy('totalPoints', 'desc'), limit(100));

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => doc.data() as UserProfile);
}

// NOTE: This is a simplified evaluation function. 
// In a real-world scenario, this would be a scheduled cloud function
// that runs periodically to evaluate finished matches.
export async function evaluateMatchPredictions(matchId: number, finalHomeScore: number, finalAwayScore: number) {
  const predictionsRef = collection(db, 'predictions');
  const q = query(predictionsRef, where('matchId', '==', matchId), where('status', '==', 'locked'));
  
  const querySnapshot = await getDocs(q);
  if (querySnapshot.empty) {
    console.log(`No pending predictions found for match ${matchId}`);
    return;
  }

  const batch = writeBatch(db);
  
  const actualWinner = finalHomeScore > finalAwayScore ? 'home' : finalHomeScore < finalAwayScore ? 'away' : 'draw';

  for (const docSnapshot of querySnapshot.docs) {
    const prediction = docSnapshot.data() as Prediction;
    const predictedWinner = prediction.homeScore > prediction.awayScore ? 'home' : prediction.homeScore < prediction.awayScore ? 'away' : 'draw';
    
    let points = 0;
    if (prediction.homeScore === finalHomeScore && prediction.awayScore === finalAwayScore) {
      points = 5; // Exact score
    } else if (predictedWinner === actualWinner) {
      points = 3; // Correct outcome
    }

    const predictionRef = doc(db, 'predictions', docSnapshot.id);
    batch.update(predictionRef, { points, status: 'evaluated' });

    if (points > 0) {
      const userRef = doc(db, 'users', prediction.userId);
      batch.update(userRef, { 
          totalPoints: increment(points),
          correctPredictions: increment(1)
      });
    }
  }

  await batch.commit();
  console.log(`Evaluated ${querySnapshot.size} predictions for match ${matchId}`);
}
