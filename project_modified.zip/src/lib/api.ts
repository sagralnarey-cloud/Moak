
import type { Competition, Team, Match } from "@/types";
import { collection, query, where, getDocs, Timestamp, orderBy, doc, getDoc, documentId } from "firebase/firestore";
import { db } from "./firebase";

const simulateDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const mapDocToMatch = async (d: any, allTeams: Team[], allCompetitions: Competition[]): Promise<Match | null> => {
    const data = d.data();
    const findTeamByName = (name: string) => allTeams.find(t => t.name === name);
    const findCompetitionByName = (name: string) => allCompetitions.find(c => c.name === name);

    const homeTeam = findTeamByName(data.homeTeam);
    const awayTeam = findTeamByName(data.awayTeam);
    const competition = findCompetitionByName(data.league);

    if (!homeTeam || !awayTeam || !competition) return null;

    const [homeScore, awayScore] = data.score ? data.score.split('-').map(Number) : [null, null];
    let status: Match['status'] = "SCHEDULED";
    switch (data.status) {
        case 'FT': case 'AET': case 'PEN': status = 'FINISHED'; break;
        case '1H': case 'HT': case '2H': case 'ET': case 'P': case 'LIVE': status = 'LIVE'; break;
        case 'TBD': case 'NS': status = 'SCHEDULED'; break;
    }
    const matchDate = data.startTime ? new Date(data.startTime.toMillis()) : new Date();
    const time = data.status === 'NS' ? new Date(matchDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) : data.status;

    return {
        id: parseInt(d.id, 10),
        competition,
        homeTeam,
        awayTeam,
        homeScore,
        awayScore,
        status,
        time,
        date: matchDate,
    };
};

export const getCompetitions = async (): Promise<Competition[]> => {
  // In a real app, this would fetch from Firestore/API
  // Returning static data for now
  await simulateDelay(20);
  return [
    { id: 39, name: "Premier League", logo: "https://media.api-sports.io/football/leagues/39.png" },
    { id: 140, name: "La Liga", logo: "https://media.api-sports.io/football/leagues/140.png" },
    // ... add other competitions
  ];
};

export const getTeams = async (): Promise<Team[]> => {
  // In a real app, this would fetch from Firestore/API
  // Returning static data for now
  await simulateDelay(20);
  return [
    // Premier League
    { id: 33, name: "Manchester United", competitionId: 39, logo: "https://media.api-sports.io/football/teams/33.png" },
    { id: 40, name: "Liverpool", competitionId: 39, logo: "https://media.api-sports.io/football/teams/40.png" },
    { id: 42, name: "Arsenal", competitionId: 39, logo: "https://media.api-sports.io/football/teams/42.png" },
    { id: 50, name: "Manchester City", competitionId: 39, logo: "https://media.api-sports.io/football/teams/50.png" },
    
    // La Liga
    { id: 529, name: "Barcelona", competitionId: 140, logo: "https://media.api-sports.io/football/teams/529.png" },
    { id: 541, name: "Real Madrid", competitionId: 140, logo: "https://media.api-sports.io/football/teams/541.png" },
  ];
};

export const getMatches = async (): Promise<Match[]> => {
  // This function is no longer the primary source for match data,
  // as components now fetch directly from Firestore.
  // It's kept for now to avoid breaking any other potential dependencies,
  // but it returns an empty array.
  await simulateDelay(50);
  return [];
};


export const getMatchesForPrediction = async (competitionIds: number[]): Promise<Match[]> => {
    const [allTeams, allCompetitions] = await Promise.all([getTeams(), getCompetitions()]);
    const competitionNames = allCompetitions.filter(c => competitionIds.includes(c.id)).map(c => c.name);

    if (competitionNames.length === 0) return [];

    const q = query(
        collection(db, "matches"),
        where("league", "in", competitionNames),
        where("status", "==", "NS"), // Not Started
        orderBy("startTime", "asc")
    );

    const querySnapshot = await getDocs(q);
    const matches = await Promise.all(
        querySnapshot.docs.map(d => mapDocToMatch(d, allTeams, allCompetitions))
    );
    return matches.filter((m): m is Match => m !== null);
}

export const getPredictedMatches = async (matchIds: number[]): Promise<Match[]> => {
    if (matchIds.length === 0) return [];

    const [allTeams, allCompetitions] = await Promise.all([getTeams(), getCompetitions()]);
    const stringMatchIds = matchIds.map(String);

    // Firestore `in` query is limited to 30 items. We might need to batch this.
    // For now, assuming matchIds.length <= 30
    const q = query(collection(db, "matches"), where(documentId(), "in", stringMatchIds));
    const querySnapshot = await getDocs(q);
    
    const matches = await Promise.all(
        querySnapshot.docs.map(d => mapDocToMatch(d, allTeams, allCompetitions))
    );
     return matches.filter((m): m is Match => m !== null);
}
