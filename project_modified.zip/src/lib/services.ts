// 🔗 ربط Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";

// 🔗 ربط API-Football
import axios from "axios";

// ✅ إعدادات Firebase
const firebaseConfig = {
  apiKey: "AIzaSyB3ZhM2N3E75pCG5UcarTarn1iuUGSxsvU",
  authDomain: "iqfb-74f77.firebaseapp.com",
  projectId: "iqfb-74f77",
  storageBucket: "iqfb-74f77.appspot.com",
  messagingSenderId: "161946927081",
  appId: "1:161946927081:web:ad254a344dd4b1061e5578"
};

// ✅ تهيئة Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();

// ✅ تسجيل الدخول عبر Gmail
export async function loginWithGoogle() {
  try {
    const result = await signInWithPopup(auth, provider);
    return result.user;
  } catch (error) {
    console.error("Login failed:", error);
    return null;
  }
}

// ✅ جلب المباريات من API-Football
const API_KEY = "827bdde6bdf871e57a55e23150948631";
const BASE_URL = "https://api-football-v1.p.rapidapi.com/v3/fixtures";

export async function fetchMatches(leagueId: number, date: string) {
  const response = await axios.get(BASE_URL, {
    params: { league: leagueId, date },
    headers: {
      "X-RapidAPI-Key": API_KEY,
      "X-RapidAPI-Host": "api-football-v1.p.rapidapi.com"
    }
  });
  return response.data;
}
