import type { User } from 'firebase/auth';

export interface Team {
  id: number;
  competitionId: number;
  name: string;
  logo: string;
}

export interface Competition {
  id: number;
  name: string;
  logo: string;
}

export type MatchStatus = "LIVE" | "FINISHED" | "SCHEDULED";

export interface Match {
  id: number;
  competition: Competition;
  status: MatchStatus;
  time: string; // Could be '90+5' for live, 'FT' for finished, or '18:00' for scheduled
  date?: string; // Changed to string to be serializable for Server Components
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number | null;
  awayScore: number | null;
  userPrediction?: Prediction;
}

export interface Article {
  id: string;
  title: string;
  content: string;
  timestamp: any;
}

export interface Prediction {
    id: string;
    userId: string;
    matchId: number;
    homeScore: number;
    awayScore: number;
    timestamp: any;
    status: 'pending' | 'locked' | 'evaluated';
    points?: number;
}

export interface UserProfile {
    id: string;
    displayName: string | null;
    email: string | null;
    photoURL: string | null;
    totalPoints?: number;
    correctPredictions?: number;
}

export interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signIn: () => Promise<void>;
  signOutUser: () => Promise<void>;
}
