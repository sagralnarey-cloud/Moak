
"use client";

import { useEffect, useState } from 'react';
import Image from "next/image";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import type { Match, Team, Competition } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Clock, Tv, Shield, Trophy, Users, FileText, BarChart2 } from "lucide-react";
import { Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { getCompetitions, getTeams } from '@/lib/api';
import { useLanguage } from '@/hooks/use-language';
import { translations } from '@/data/translations';

export default function MatchDetailsPage({ params }: { params: { matchId: string } }) {
  const [match, setMatch] = useState<Match | null>(null);
  const [loading, setLoading] = useState(true);
  const { language } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    const fetchMatchAndMetadata = async () => {
      setLoading(true);
      
      const matchDocRef = doc(db, "matches", params.matchId);
      const matchDoc = await getDoc(matchDocRef);

      if (matchDoc.exists()) {
        const data = matchDoc.data();
        
        // Fetch metadata only for the required teams and competition
        const [allTeams, allCompetitions] = await Promise.all([getTeams(), getCompetitions()]);

        const homeTeam = allTeams.find(t => t.name === data.homeTeam);
        const awayTeam = allTeams.find(t => t.name === data.awayTeam);
        const competition = allCompetitions.find(c => c.name === data.league);
        
        if (homeTeam && awayTeam && competition) {
             const [homeScore, awayScore] = data.score ? data.score.split('-').map(Number) : [null, null];
            
            let status: Match['status'] = "SCHEDULED";
            switch(data.status) {
                case 'FT': case 'AET': case 'PEN': status = 'FINISHED'; break;
                case '1H': case 'HT': case '2H': case 'ET': case 'P': case 'LIVE': status = 'LIVE'; break;
                case 'TBD': case 'NS': status = 'SCHEDULED'; break;
            }

            let time = data.status;
            if (status === 'SCHEDULED' && data.startTime) {
                 time = new Date(data.startTime.toMillis()).toLocaleTimeString(language === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
            }

            setMatch({
                id: parseInt(matchDoc.id, 10),
                competition: {
                    ...competition,
                    name: t.competitions[competition.name as keyof typeof t.competitions] || competition.name
                },
                homeTeam: {
                    ...homeTeam,
                    name: t.teams[homeTeam.name as keyof typeof t.teams] || homeTeam.name
                },
                awayTeam: {
                    ...awayTeam,
                    name: t.teams[awayTeam.name as keyof typeof t.teams] || awayTeam.name
                },
                homeScore: homeScore,
                awayScore: awayScore,
                status: status,
                time: time,
                date: data.startTime ? new Date(data.startTime.toMillis()) : new Date(),
            });
        }
      }
      setLoading(false);
    };

    fetchMatchAndMetadata();
  }, [params.matchId, language, t.competitions, t.teams]);

  if (loading) {
    return <div className="flex items-center justify-center p-8 h-full"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  if (!match) {
    return <div className="text-center p-8">Match not found.</div>;
  }
  
  const matchDate = (match.date || new Date()).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="bg-muted/40 min-h-full">
      <div className="container py-4 space-y-4">
        {/* Header */}
        <Card className="overflow-hidden">
          <CardHeader className="p-0">
             <div className="bg-card p-4 flex flex-col items-center justify-center text-center space-y-2">
                <Image src={match.competition.logo} alt={match.competition.name} width={40} height={40} data-ai-hint="competition logo" />
                <h2 className="text-lg font-semibold">{match.competition.name}</h2>
                <p className="text-sm text-muted-foreground">{matchDate}</p>
            </div>
          </CardHeader>
          <CardContent className="p-4 flex justify-around items-center">
            <div className="flex flex-col items-center gap-2 w-1/3 text-center">
              <Image src={match.homeTeam.logo} alt={match.homeTeam.name} width={56} height={56} className="h-14 w-14" data-ai-hint="team logo" />
              <h3 className="font-bold text-md">{match.homeTeam.name}</h3>
            </div>
            <div className="text-4xl font-extrabold w-1/3 text-center">
              {match.status === "SCHEDULED" ? match.time : `${match.homeScore} - ${match.awayScore}`}
            </div>
            <div className="flex flex-col items-center gap-2 w-1/3 text-center">
              <Image src={match.awayTeam.logo} alt={match.awayTeam.name} width={56} height={56} className="h-14 w-14" data-ai-hint="team logo"/>
              <h3 className="font-bold text-md">{match.awayTeam.name}</h3>
            </div>
          </CardContent>
           <div className="bg-card p-2 text-center text-muted-foreground text-sm font-semibold border-t">
              {match.status === "LIVE" && <Badge variant="destructive" className="animate-pulse">{match.time}' | Live</Badge>}
              {match.status === "FINISHED" && <span>Full Time</span>}
              {match.status === "SCHEDULED" && <span>Scheduled</span>}
            </div>
        </Card>

        <Accordion type="multiple" defaultValue={['match-info']} className="space-y-4">
            {/* Match Info */}
            <Card>
                 <AccordionItem value="match-info" className="border-b-0">
                    <AccordionTrigger className="p-4">
                        <h3 className="font-semibold flex items-center gap-2"><Trophy className="w-5 h-5" /> Match Info</h3>
                    </AccordionTrigger>
                    <AccordionContent className="p-4 pt-0">
                        <div className="space-y-3 text-sm">
                            <div className="flex justify-between">
                                <span className="text-muted-foreground flex items-center gap-2"><Calendar className="w-4 h-4"/> Date</span>
                                <span>{matchDate}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground flex items-center gap-2"><Clock className="w-4 h-4"/> Kick-off</span>
                                <span>{match.time}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-muted-foreground flex items-center gap-2"><Shield className="w-4 h-4"/> Competition</span>
                                <span>{match.competition.name}</span>
                            </div>
                             <div className="flex justify-between">
                                <span className="text-muted-foreground flex items-center gap-2"><Tv className="w-4 h-4"/> Channels</span>
                                <span>Not available</span>
                            </div>
                        </div>
                    </AccordionContent>
                </AccordionItem>
            </Card>

            {/* Lineups */}
            <Card>
                <AccordionItem value="lineups" className="border-b-0">
                    <AccordionTrigger className="p-4">
                        <h3 className="font-semibold flex items-center gap-2"><Users className="w-5 h-5" /> Lineups</h3>
                    </AccordionTrigger>
                    <AccordionContent className="p-4 pt-0 text-center">
                       <p className="text-muted-foreground">Lineups are not yet available for this match.</p>
                    </AccordionContent>
                </AccordionItem>
            </Card>

             {/* Standings */}
            <Card>
                <AccordionItem value="standings" className="border-b-0">
                    <AccordionTrigger className="p-4">
                        <h3 className="font-semibold flex items-center gap-2"><BarChart2 className="w-5 h-5" /> Standings</h3>
                    </AccordionTrigger>
                    <AccordionContent className="p-0">
                       <p className="text-muted-foreground p-4 text-center">Standings data is not available for this match.</p>
                    </AccordionContent>
                </AccordionItem>
            </Card>

             {/* Match Events */}
            <Card>
                <AccordionItem value="events" className="border-b-0">
                    <AccordionTrigger className="p-4">
                        <h3 className="font-semibold flex items-center gap-2"><FileText className="w-5 h-5" /> Match Events</h3>
                    </AccordionTrigger>
                    <AccordionContent className="p-4 pt-0 text-center">
                         <p className="text-muted-foreground">No match events to show.</p>
                    </AccordionContent>
                </AccordionItem>
            </Card>
        </Accordion>
        
      </div>
    </div>
  );
}
