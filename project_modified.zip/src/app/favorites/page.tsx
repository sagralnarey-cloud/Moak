
"use client";

import { useMemo, useState, useEffect } from "react";
import type { Competition, Team } from "@/types";
import { useFavorites } from "@/hooks/use-favorites";
import { Loader2, Star } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import Image from 'next/image';
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { cn } from "@/lib/utils";
import { getCompetitions, getTeams } from "@/lib/api";

export default function FavoritesPage() {
  const [allCompetitions, setAllCompetitions] = useState<Competition[]>([]);
  const [allTeams, setAllTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const { isFavorite, toggleFavorite } = useFavorites();
  const { language } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    setIsLoading(true);
    Promise.all([getCompetitions(), getTeams()]).then(([comps, teams]) => {
      setAllCompetitions(comps);
      setAllTeams(teams);
      setIsLoading(false);
    });
  }, []);

  const competitions = useMemo(() => {
    return allCompetitions.map(c => ({...c, name: t.competitions[c.name as keyof typeof t.competitions] || c.name }));
  }, [allCompetitions, t.competitions]);

  const teamsByCompetition = useMemo(() => {
    return allTeams.reduce(
      (acc, team) => {
        if (!acc[team.competitionId]) {
          acc[team.competitionId] = [];
        }
        const translatedTeam = {...team, name: t.teams[team.name as keyof typeof t.teams] || team.name };
        acc[team.competitionId].push(translatedTeam);
        return acc;
      },
      {} as { [key: number]: Team[] }
    );
  }, [allTeams, t.teams]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8 h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
       <Card>
        <CardHeader>
          <CardTitle>{t.more.managePrefs}</CardTitle>
          <CardDescription>
            {t.more.myAccountDesc}
          </CardDescription>
        </CardHeader>
      </Card>

      <Accordion type="multiple" className="w-full space-y-2">
        {competitions.map((comp) => (
          <Card key={comp.id}>
            <AccordionItem value={`competition-${comp.id}`} className="border-b-0">
               <div className="flex items-center p-4">
                  <Star
                    className={cn(
                      "h-6 w-6 cursor-pointer text-muted-foreground transition-colors hover:text-amber-500",
                      isFavorite(comp.id, "competitions") && "text-amber-400 fill-amber-400"
                    )}
                    onClick={() => toggleFavorite(comp.id, "competitions")}
                  />
                  <AccordionTrigger className="flex-1 p-0 pl-4 hover:no-underline">
                      <div className="flex items-center gap-4">
                        <Image src={comp.logo} alt={comp.name} width={32} height={32} data-ai-hint="competition logo" />
                        <span className="font-semibold">{comp.name}</span>
                      </div>
                  </AccordionTrigger>
              </div>
              <AccordionContent>
                <div className="space-y-2 pl-8 pr-4 pb-4">
                   {(teamsByCompetition[comp.id] || []).map((team) => (
                    <div key={team.id} className="flex items-center space-x-4 p-2 rounded-md hover:bg-muted">
                       <Star
                          className={cn(
                            "h-5 w-5 cursor-pointer text-muted-foreground transition-colors hover:text-amber-500",
                            isFavorite(team.id, "teams") && "text-amber-400 fill-amber-400"
                          )}
                          onClick={() => toggleFavorite(team.id, "teams")}
                        />
                       <Image src={team.logo} alt={team.name} width={24} height={24} data-ai-hint="team logo" />
                      <label
                        htmlFor={`team-${team.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex-1 cursor-pointer"
                        onClick={() => toggleFavorite(team.id, "teams")}
                      >
                        {team.name}
                      </label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Card>
        ))}
      </Accordion>
    </div>
  );
}
