
"use client";

import { useMemo, useState, useEffect } from "react";
import type { Match, Prediction, UserProfile } from "@/types";
import { Loader2, Crown, Medal, Trophy } from "lucide-react";
import { PredictionCard } from "@/components/prediction-card";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { useAuth } from "@/hooks/use-auth";
import { getUserPredictions, getLeaderboard } from "@/lib/predictions";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { getMatchesForPrediction } from "@/lib/api";

const PREDICTION_LEAGUE_IDS = [39, 140]; // Premier League & La Liga

function UpcomingMatchesTab() {
  const [allMatches, setAllMatches] = useState<Match[]>([]);
  const [isLoadingMatches, setIsLoadingMatches] = useState(true);

  const { user } = useAuth();
  const [userPredictions, setUserPredictions] = useState<Prediction[]>([]);
  const [isLoadingPredictions, setIsLoadingPredictions] = useState(true);

  useEffect(() => {
    setIsLoadingMatches(true);
    getMatchesForPrediction(PREDICTION_LEAGUE_IDS).then(matches => {
        setAllMatches(matches);
        setIsLoadingMatches(false);
    })
  }, [])

  useEffect(() => {
    if (user) {
      setIsLoadingPredictions(true);
      getUserPredictions(user.uid).then(preds => {
        setUserPredictions(preds);
        setIsLoadingPredictions(false);
      });
    } else {
      setUserPredictions([]);
      setIsLoadingPredictions(false);
    }
  }, [user]);

  const matchesForPrediction = useMemo(() => {
    return allMatches
      .map(match => ({
          ...match,
          userPrediction: userPredictions.find(p => p.matchId === match.id)
      }));
  }, [allMatches, userPredictions]);
  
  const isLoading = isLoadingMatches || (user && isLoadingPredictions);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (matchesForPrediction.length === 0) {
    return (
       <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">No upcoming matches available for predictions in the Premier League or La Liga right now.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {matchesForPrediction.map((match) => (
        <PredictionCard key={match.id} match={match} />
      ))}
    </div>
  );
}

function MyPredictionsTab() {
    const [predictedMatches, setPredictedMatches] = useState<Match[]>([]);
    const { user } = useAuth();
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (user) {
            setIsLoading(true);
            getUserPredictions(user.uid, true).then(matches => {
                setPredictedMatches(matches);
                setIsLoading(false);
            });
        } else {
            setPredictedMatches([]);
            setIsLoading(false);
        }
    }, [user]);

    if (isLoading) {
        return <div className="flex items-center justify-center p-8"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }
    
    if (!user) {
         return <Card><CardContent className="p-6 text-center text-muted-foreground">Please sign in to see your predictions.</CardContent></Card>;
    }

    if (predictedMatches.length === 0) {
        return <Card><CardContent className="p-6 text-center text-muted-foreground">You haven't made any predictions yet.</CardContent></Card>;
    }
    
    return (
        <div className="space-y-4">
            {predictedMatches.map(match => (
                <PredictionCard key={`my-pred-${match.id}`} match={match} />
            ))}
        </div>
    );
}

function LeaderboardTab() {
    const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        getLeaderboard().then(data => {
            setLeaderboard(data);
            setIsLoading(false);
        });
    }, []);
    
    const getRankIcon = (rank: number) => {
        if (rank === 0) return <Crown className="w-6 h-6 text-yellow-500" />;
        if (rank === 1) return <Medal className="w-6 h-6 text-gray-400" />;
        if (rank === 2) return <Trophy className="w-6 h-6 text-yellow-700" />;
        return <span className="font-bold text-lg w-6 text-center">{rank + 1}</span>;
    }
    
    const getRankCardClass = (rank: number) => {
        if (rank === 0) return "border-yellow-500 border-2";
        if (rank === 1) return "border-gray-400 border-2";
        if (rank === 2) return "border-yellow-700 border-2";
        return "";
    }

    if (isLoading) {
        return <div className="flex items-center justify-center p-8"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }

    if (leaderboard.length === 0) {
        return <Card><CardContent className="p-6 text-center text-muted-foreground">Leaderboard is empty. Be the first to make a prediction!</CardContent></Card>;
    }

    return (
        <div className="space-y-3">
            {leaderboard.map((player, index) => (
                <Card key={player.id} className={cn("flex items-center p-3 gap-3", getRankCardClass(index))}>
                    <div>{getRankIcon(index)}</div>
                    <Avatar>
                        <AvatarImage src={player.photoURL || ''} alt={player.displayName || 'User'} />
                        <AvatarFallback>{player.displayName?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                        <p className="font-semibold">{player.displayName}</p>
                        <p className="text-xs text-muted-foreground">{player.correctPredictions || 0} correct predictions</p>
                    </div>
                    <div className="text-right">
                        <p className="font-bold text-lg text-primary">{player.totalPoints || 0}</p>
                        <p className="text-xs text-muted-foreground">points</p>
                    </div>
                </Card>
            ))}
        </div>
    )
}


export default function PredictionsPage() {
  const { userProfile } = useAuth();
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <div className="p-4 space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Your Weekly Score</CardTitle>
          <CardDescription>Points are reset weekly. Good luck!</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-4xl font-bold">{userProfile?.totalPoints || 0} Points</p>
        </CardContent>
      </Card>
      
       <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="my-predictions">My Predictions</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
        </TabsList>
        <TabsContent value="upcoming" className="pt-4">
            <UpcomingMatchesTab />
        </TabsContent>
        <TabsContent value="my-predictions" className="pt-4">
            <MyPredictionsTab />
        </TabsContent>
        <TabsContent value="leaderboard" className="pt-4">
            <LeaderboardTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
