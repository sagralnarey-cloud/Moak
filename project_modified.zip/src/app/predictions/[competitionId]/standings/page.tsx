
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getCompetitions } from "@/lib/api";

// This is a placeholder. We'll replace it with API data later.
const standingsData: any[] = [];

const topScorersData: any[] = [];


export default async function StandingsPage({
  params,
}: {
  params: { competitionId: string };
}) {
  const competitionId = parseInt(params.competitionId, 10);
  // Fetch a specific competition, or get a placeholder name if not found
  const allCompetitions = await getCompetitions();
  const competition = allCompetitions.find((c) => c.id === competitionId);
  const competitionName = competition ? competition.name : "League";

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">{competitionName}</h1>
      <Tabs defaultValue="standings">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="standings">League Standings</TabsTrigger>
          <TabsTrigger value="top-scorers">Top Scorers</TabsTrigger>
        </TabsList>
        <TabsContent value="standings">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rank</TableHead>
                    <TableHead>Team</TableHead>
                    <TableHead className="text-right">Points</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                   {standingsData.length === 0 && (
                    <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground">
                            Standings data is not available yet.
                        </TableCell>
                    </TableRow>
                  )}
                  {standingsData.map((item) => (
                    <TableRow key={item.rank}>
                      <TableCell>{item.rank}</TableCell>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell className="text-right">{item.points}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="top-scorers">
            <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rank</TableHead>
                    <TableHead>Player</TableHead>
                    <TableHead className="text-right">Goals</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topScorersData.length === 0 && (
                    <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground">
                           Top scorers data is not available yet.
                        </TableCell>
                    </TableRow>
                  )}
                  {topScorersData.map((item) => (
                    <TableRow key={item.rank}>
                      <TableCell>{item.rank}</TableCell>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell className="text-right">{item.goals}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
