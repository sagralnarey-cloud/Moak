
import ResultsTabs from "@/components/results-tabs";
import { collection, getDocs, query, where, Timestamp, orderBy } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { getTeams, getCompetitions } from "@/lib/api";
import { eachDayOfInterval, subDays, addDays, startOfDay, endOfDay } from "date-fns";
import type { Match, Team, Competition } from "@/types";

// Re-export this so it's only defined in one place
export const revalidate = 60; // Revalidate data every 60 seconds

async function getMatches() {
    try {
        const [teams, competitions] = await Promise.all([getTeams(), getCompetitions()]);

        const dateInterval = {
            start: subDays(new Date(), 7),
            end: addDays(new Date(), 7)
        };
        const start = startOfDay(dateInterval.start);
        const end = endOfDay(dateInterval.end);

        const q = query(
            collection(db, "matches"),
            where("startTime", ">=", Timestamp.fromDate(start)),
            where("startTime", "<=", Timestamp.fromDate(end)),
            orderBy("startTime", "asc")
        );
        
        const querySnapshot = await getDocs(q);

        const findTeamByName = (name: string) => teams.find(t => t.name === name);
        const findCompetitionByName = (name: string) => competitions.find(c => c.name === name);

        const fetchedMatches: Match[] = [];
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            const homeTeam = findTeamByName(data.homeTeam);
            const awayTeam = findTeamByName(data.awayTeam);
            const competition = findCompetitionByName(data.league);

            if (homeTeam && awayTeam && competition) {
                const [homeScore, awayScore] = data.score ? data.score.split('-').map(Number) : [null, null];
                let status: Match['status'] = "SCHEDULED";
                switch (data.status) {
                    case 'FT': case 'AET': case 'PEN': status = 'FINISHED'; break;
                    case '1H': case 'HT': case '2H': case 'ET': case 'P': case 'LIVE': status = 'LIVE'; break;
                    case 'TBD': case 'NS': status = 'SCHEDULED'; break;
                }
                const matchDate = data.startTime ? data.startTime.toDate() : new Date();
                const time = data.status === 'NS' ? new Date(matchDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }) : data.status;

                fetchedMatches.push({
                    id: parseInt(doc.id, 10),
                    competition,
                    homeTeam,
                    awayTeam,
                    homeScore,
                    awayScore,
                    status,
                    time,
                    date: matchDate.toISOString(), // Convert to string for serialization
                });
            }
        });
        return fetchedMatches;

    } catch (error) {
         console.error("Error fetching data:", error);
         return [];
    }
}

export default async function Home() {
  const matches = await getMatches();
  const dateInterval = {
      start: subDays(new Date(), 7),
      end: addDays(new Date(), 7)
  };
  const allDatesInRange = eachDayOfInterval(dateInterval).map(d => d.toISOString());

  return (
    <div className="flex flex-col flex-1">
      <ResultsTabs matches={matches} dates={allDatesInRange} />
    </div>
  );
}
