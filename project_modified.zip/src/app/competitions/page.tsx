
"use client";

import { useMemo, useState, useEffect } from "react";
import { useFavorites } from "@/hooks/use-favorites";
import type { Competition } from "@/types";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { EmptyState } from "@/components/empty-state";
import Image from "next/image";
import Link from "next/link";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { getCompetitions } from "@/lib/api";

export default function CompetitionsPage() {
  const [allCompetitions, setAllCompetitions] = useState<Competition[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { favoriteCompetitions } = useFavorites();
  const { language } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    setIsLoading(true);
    getCompetitions().then(comps => {
      setAllCompetitions(comps);
      setIsLoading(false);
    });
  }, []);

  const competitions = useMemo(() => {
     const favoriteComps = allCompetitions.filter((c) =>
        favoriteCompetitions.includes(c.id)
      );

      const translatedCompetitions = favoriteComps.map(comp => ({
          ...comp,
          name: t.competitions[comp.name as keyof typeof t.competitions] || comp.name
      }));
      
      return translatedCompetitions;

  }, [allCompetitions, favoriteCompetitions, language, t.competitions]);


  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8 h-full">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (competitions.length === 0) {
    return (
      <EmptyState
        title="No Favorite Competitions"
        description="Select your favorite competitions in the Favorites tab to see them here."
      />
    );
  }

  return (
    <div className="p-4 space-y-4">
      {competitions.map((competition) => (
        <Card key={competition.id}>
          <CardHeader className="flex flex-row items-center gap-4">
            <Image
              src={competition.logo}
              alt={competition.name}
              width={40}
              height={40}
              className="h-10 w-10"
              data-ai-hint="competition logo"
            />
            <div>
              <CardTitle>{competition.name}</CardTitle>
              <CardDescription>View standings and top scorers</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="flex gap-2">
            <Button asChild variant="outline" className="w-full">
                <Link href={`/predictions/${competition.id}/standings`}>League Standings</Link>
            </Button>
            <Button asChild variant="outline" className="w-full">
                <Link href={`/predictions/${competition.id}/standings`}>Top Scorers</Link>
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
