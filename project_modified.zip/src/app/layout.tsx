
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/providers/theme-provider";
import { Toaster } from "@/components/ui/toaster";
import MainLayout from "@/components/layout/main-layout";
import { WelcomeScreen } from "@/components/welcome-screen";
import { DeveloperProvider } from "@/components/providers/developer-provider";
import { LanguageProvider } from "@/components/providers/language-provider";
import { AuthProvider } from "@/components/providers/auth-provider";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "GoalPulse",
  description: "Your daily dose of football scores.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            <DeveloperProvider>
              <LanguageProvider>
                <WelcomeScreen />
                <MainLayout>{children}</MainLayout>
                <Toaster />
              </LanguageProvider>
            </DeveloperProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
