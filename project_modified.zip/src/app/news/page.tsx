import {
  collection,
  query,
  orderBy,
  getDocs,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardDescription,
} from "@/components/ui/card";
import { Newspaper } from "lucide-react";
import type { Article } from "@/types";
import { NewsClient } from "@/components/news-client";


async function getNews(): Promise<Article[]> {
    try {
        const q = query(collection(db, "news"), orderBy("timestamp", "desc"));
        const snapshot = await getDocs(q);
        
        const fetchedArticles: Article[] = snapshot.docs.map((doc) => ({
            id: doc.id,
            title: doc.data().title,
            content: doc.data().content,
            timestamp: doc.data().timestamp.toDate(),
        }));
        return fetchedArticles;
      } catch (error) {
         console.error("Error fetching news:", error);
         return [];
      }
}


export default async function NewsPage() {
  const articles = await getNews();

  if (!articles || articles.length === 0) {
    return (
        <div className="flex flex-1 items-center justify-center pt-16 p-4">
          <Card className="w-full max-w-md m-4 border-dashed">
            <CardHeader className="text-center">
              <div className="mx-auto bg-muted rounded-full p-3 w-fit mb-2">
                <Newspaper className="h-8 w-8 text-muted-foreground" />
              </div>
              <CardTitle>No News Yet</CardTitle>
              <CardDescription>
                Check back later for the latest updates.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      );
  }

  return <NewsClient initialArticles={articles} />;
}
