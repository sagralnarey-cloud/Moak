
"use client";

import { useRef, useState } from "react";
import { ThemeToggle } from "@/components/theme-toggle";
import { LanguageToggle } from "@/components/language-toggle";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  ChevronRight,
  CreditCard,
  Bell,
  Info,
  Palette,
  Languages,
  Code,
  Globe,
  Instagram,
  Twitter,
  Facebook,
  LogIn,
  LogOut,
  BellOff,
} from "lucide-react";
import { useDeveloper } from "@/hooks/use-developer";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const REQUIRED_TAPS = 5;
const TAP_TIMEOUT = 4000; // 4 seconds
const LONG_PRESS_DURATION = 6000; // 6 seconds
const DEV_CODE = "1947";

export default function MorePage() {
  const { isDeveloperMode, enableDeveloperMode, disableDeveloperMode } = useDeveloper();
  const { toast } = useToast();
  const { language } = useLanguage();
  const t = translations[language];
  const { user, userProfile, signIn, signOutUser, loading } = useAuth();

  const [showCodePrompt, setShowCodePrompt] = useState(false);
  const [showResetPrompt, setShowResetPrompt] = useState(false);
  const [devCode, setDevCode] = useState("");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const tapCount = useRef(0);
  const tapTimeout = useRef<NodeJS.Timeout | null>(null);
  const longPressTimeout = useRef<NodeJS.Timeout | null>(null);

  const handleAboutClick = () => {
    if (isDeveloperMode) return;

    if (tapTimeout.current) {
      clearTimeout(tapTimeout.current);
    }
    tapCount.current += 1;
    if (tapCount.current >= REQUIRED_TAPS) {
      tapCount.current = 0;
      setShowCodePrompt(true);
    }
    tapTimeout.current = setTimeout(() => {
      tapCount.current = 0;
    }, TAP_TIMEOUT);
  };

  const handleCodeSubmit = () => {
    if (devCode === DEV_CODE) {
      enableDeveloperMode();
      toast({ title: t.more.devModeEnabled });
      setShowCodePrompt(false);
    } else {
      toast({
        variant: "destructive",
        title: t.more.incorrectCode,
        description: t.more.incorrectCodeDesc,
      });
    }
    setDevCode("");
  };

  const handleAboutPressStart = () => {
    if (!isDeveloperMode) return;
    longPressTimeout.current = setTimeout(() => {
      setShowResetPrompt(true);
    }, LONG_PRESS_DURATION);
  };

  const handleAboutPressEnd = () => {
    if (longPressTimeout.current) {
      clearTimeout(longPressTimeout.current);
    }
  };

  const handleResetConfirm = () => {
    disableDeveloperMode();
    toast({ title: t.more.devModeDisabled });
    setShowResetPrompt(false);
  };
  
  const tMore = t.more;

  const renderAuthCard = () => {
    if (loading) {
      return <Card><CardContent className="p-4"><div className="h-24 bg-muted rounded-md animate-pulse"></div></CardContent></Card>
    }

    if (user && userProfile) {
      return (
        <Card>
          <CardHeader className="flex flex-row items-center gap-4">
            <Avatar className="h-12 w-12">
              <AvatarImage src={userProfile.photoURL || ''} alt={userProfile.displayName || 'User'}/>
              <AvatarFallback>{userProfile.displayName?.charAt(0) || 'U'}</AvatarFallback>
            </Avatar>
            <div>
              <CardTitle>{userProfile.displayName}</CardTitle>
              <CardDescription>{userProfile.email}</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full" onClick={signOutUser}>
              <LogOut className="mr-2" /> Sign Out
            </Button>
          </CardContent>
        </Card>
      )
    }

    return (
       <Card>
          <CardHeader>
              <CardTitle>{tMore.myAccount}</CardTitle>
              <CardDescription>{tMore.myAccountDesc}</CardDescription>
          </CardHeader>
          <CardContent>
              <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" onClick={signIn}>
                      <div className="flex items-center gap-3">
                          <Globe className="w-5 h-5 text-muted-foreground" />
                          <span>{tMore.connectGoogle}</span>
                      </div>
                  </Button>
              </div>
          </CardContent>
      </Card>
    )
  }

  return (
    <>
      <div className="p-4 space-y-4">
        
        {renderAuthCard()}

        <Card>
          <CardHeader>
            <CardTitle>{tMore.settings}</CardTitle>
            <CardDescription>
              {tMore.managePrefs}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted">
              <div className="flex items-center gap-3">
                <Palette className="w-5 h-5 text-muted-foreground" />
                <span>{tMore.themes}</span>
              </div>
              <ThemeToggle />
            </div>
            <Separator />
            <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted">
              <div className="flex items-center gap-3">
                <Languages className="w-5 h-5 text-muted-foreground" />
                <span>{tMore.language}</span>
              </div>
              <LanguageToggle />
            </div>
            <Separator />
            <div className="flex items-center justify-between p-2 rounded-lg hover:bg-muted">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <span>{tMore.notifications}</span>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setNotificationsEnabled(prev => !prev)}>
                {notificationsEnabled ? <Bell className="h-5 w-5" /> : <BellOff className="h-5 w-5" />}
                <span className="sr-only">Toggle Notifications</span>
              </Button>
            </div>
            {isDeveloperMode && (
              <>
                <Separator />
                <div className="flex items-center justify-between p-2 rounded-lg bg-green-100 dark:bg-green-900/30">
                  <div className="flex items-center gap-3">
                    <Code className="w-5 h-5 text-green-600 dark:text-green-400" />
                    <span className="font-semibold text-green-800 dark:text-green-300">
                      {tMore.devModeActive}
                    </span>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-2">
            <Button variant="ghost" className="w-full justify-start p-2">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-muted-foreground" />
                  <span>{tMore.removeAds}</span>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Button>
            <Separator />
            <div
              onClick={handleAboutClick}
              onMouseDown={handleAboutPressStart}
              onMouseUp={handleAboutPressEnd}
              onTouchStart={handleAboutPressStart}
              onTouchEnd={handleAboutPressEnd}
              className="flex items-center justify-between w-full p-3 rounded-lg cursor-pointer hover:bg-muted/50"
            >
              <div className="flex items-center gap-3">
                <Info className="w-5 h-5 text-muted-foreground" />
                <span>{tMore.aboutApp}</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Developer Code Prompt */}
      <AlertDialog open={showCodePrompt} onOpenChange={setShowCodePrompt}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{tMore.enterDevCode}</AlertDialogTitle>
          </AlertDialogHeader>
          <div className="py-4">
            <Input
              type="password"
              placeholder={tMore.devCodePlaceholder}
              value={devCode}
              onChange={(e) => setDevCode(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCodeSubmit()}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>{tMore.cancel}</AlertDialogCancel>
            <AlertDialogAction onClick={handleCodeSubmit}>
              {tMore.unlock}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Reset Developer Mode Prompt */}
      <AlertDialog open={showResetPrompt} onOpenChange={setShowResetPrompt}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{tMore.resetDevMode}</AlertDialogTitle>
            <AlertDialogDescription>
             {tMore.resetDevModeDesc}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{tMore.cancel}</AlertDialogCancel>
            <AlertDialogAction onClick={handleResetConfirm}>
              {tMore.yesReset}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

    