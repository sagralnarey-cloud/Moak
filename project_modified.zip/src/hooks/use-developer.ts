
"use client";

import { useContext } from "react";
import { DeveloperContext } from "@/components/providers/developer-provider";

export const useDeveloper = () => {
  const context = useContext(DeveloperContext);
  if (context === undefined) {
    throw new Error("useDeveloper must be used within a DeveloperProvider");
  }
  return context;
};
