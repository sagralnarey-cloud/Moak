
"use client";

import { useState, useEffect, useCallback } from "react";

type FavoriteType = "teams" | "competitions";

const getInitialState = (key: string): number[] => {
  if (typeof window === "undefined") {
    return [];
  }
  try {
    const item = window.localStorage.getItem(key);
    return item ? JSON.parse(item) : [];
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const useFavorites = () => {
  const [favoriteTeams, setFavoriteTeams] = useState<number[]>(() =>
    getInitialState("favoriteTeams")
  );
  const [favoriteCompetitions, setFavoriteCompetitions] = useState<number[]>(
    () => getInitialState("favoriteCompetitions")
  );

  useEffect(() => {
    try {
      window.localStorage.setItem("favoriteTeams", JSON.stringify(favoriteTeams));
    } catch (error) {
      console.error(error);
    }
  }, [favoriteTeams]);

  useEffect(() => {
    try {
      window.localStorage.setItem(
        "favoriteCompetitions",
        JSON.stringify(favoriteCompetitions)
      );
    } catch (error) {
      console.error(error);
    }
  }, [favoriteCompetitions]);

  const toggleFavorite = useCallback((id: number, type: FavoriteType) => {
    const setFavorites = type === "teams" ? setFavoriteTeams : setFavoriteCompetitions;
    setFavorites((prev: number[]) =>
      prev.includes(id) ? prev.filter((favId) => favId !== id) : [...prev, id]
    );
  }, []);

  const isFavorite = useCallback(
    (id: number, type: FavoriteType) => {
      return type === "teams"
        ? favoriteTeams.includes(id)
        : favoriteCompetitions.includes(id);
    },
    [favoriteTeams, favoriteCompetitions]
  );

  return {
    favoriteTeams,
    favoriteCompetitions,
    toggleFavorite,
    isFavorite,
  };
};
