
"use client";
import { useState, useEffect } from "react";
import {
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  collection,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { PlusCircle } from "lucide-react";
import { useDeveloper } from "@/hooks/use-developer";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import type { Article } from "@/types";

interface NewsClientProps {
    initialArticles: Article[];
}

export function NewsClient({ initialArticles }: NewsClientProps) {
  const { isDeveloperMode } = useDeveloper();
  const [articles, setArticles] = useState<Article[]>(initialArticles);
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [articleToDelete, setArticleToDelete] = useState<Article | null>(null);
  
  const [newTitle, setNewTitle] = useState("");
  const [newContent, setNewContent] = useState("");
  const { toast } = useToast();
  
  // Sync state with server-rendered props
  useEffect(() => {
    setArticles(initialArticles);
  }, [initialArticles]);


  const handleOpenForm = (article: Article | null = null) => {
    setEditingArticle(article);
    setNewTitle(article ? article.title : "");
    setNewContent(article ? article.content : "");
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingArticle(null);
    setNewTitle("");
    setNewContent("");
  };

  const handlePublish = async () => {
    if (!newTitle || !newContent) {
      toast({
        variant: "destructive",
        title: "Missing Fields",
        description: "Please fill out both title and content.",
      });
      return;
    }

    try {
      if (editingArticle) {
        // Update existing article
        const articleRef = doc(db, "news", editingArticle.id);
        await updateDoc(articleRef, {
          title: newTitle,
          content: newContent,
        });
        setArticles(articles.map(a => a.id === editingArticle.id ? { ...a, title: newTitle, content: newContent } : a));
        toast({
          title: "Article Updated",
          description: "Your article has been successfully updated.",
        });
      } else {
        // Add new article
        const newArticleData = {
          title: newTitle,
          content: newContent,
          timestamp: serverTimestamp(),
        };
        const docRef = await addDoc(collection(db, "news"), newArticleData);
        // Optimistically add to UI, but ideally we'd get the real timestamp back
         const tempArticle: Article = {
            id: docRef.id,
            title: newTitle,
            content: newContent,
            timestamp: new Date(), // Use local date as placeholder
        };
        setArticles([tempArticle, ...articles]);

        toast({
          title: "Article Published",
          description: "Your new article is now live.",
        });
      }
      handleCloseForm();
    } catch (error) {
      console.error("Error publishing article: ", error);
      toast({
        variant: "destructive",
        title: "Publishing Failed",
        description: "Could not save the article. Please try again.",
      });
    }
  };

  const handleArticleLongPress = (e: React.MouseEvent, article: Article) => {
    e.preventDefault();
    if (!isDeveloperMode) return;
    setArticleToDelete(article);
  };
  
  const handleDelete = async () => {
    if (!articleToDelete) return;
    try {
        await deleteDoc(doc(db, "news", articleToDelete.id));
        setArticles(articles.filter(a => a.id !== articleToDelete.id));
        toast({
            title: "Article Deleted",
            description: "The article has been permanently removed.",
        });
    } catch (error) {
         console.error("Error deleting article: ", error);
        toast({
            variant: "destructive",
            title: "Deletion Failed",
            description: "Could not delete the article. Please try again.",
        });
    }
    setArticleToDelete(null);
  };

  return (
    <div className="p-4 space-y-4">
      {isDeveloperMode && (
        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogTrigger asChild>
            <Button className="w-full" onClick={() => handleOpenForm()}>
              <PlusCircle className="mr-2" />
              Add New Article
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingArticle ? "Edit Article" : "Create New Article"}</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="title" className="text-right">
                  Title
                </Label>
                <Input
                  id="title"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="content" className="text-right">
                  Content
                </Label>
                <Textarea
                  id="content"
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="col-span-3"
                  rows={8}
                />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" onClick={handleCloseForm}>Cancel</Button>
              </DialogClose>
              <Button onClick={handlePublish}>{editingArticle ? "Save Changes" : "Publish"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {articles.length > 0 ? (
        articles.map((article) => (
          <Card 
            key={article.id}
            onClick={() => isDeveloperMode && handleOpenForm(article)}
            onContextMenu={(e) => handleArticleLongPress(e, article)}
            className={isDeveloperMode ? "cursor-pointer hover:bg-muted/50 transition-colors" : ""}
          >
            <CardHeader>
              <CardTitle>{article.title}</CardTitle>
              {article.timestamp && (
                <CardDescription>
                  {new Date(article.timestamp).toLocaleString()}
                </CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground whitespace-pre-wrap">{article.content}</p>
            </CardContent>
          </Card>
        ))
      ) : (
        <p>This should not be seen if the server component works.</p>
      )}

      <AlertDialog open={!!articleToDelete} onOpenChange={() => setArticleToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this article?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The article will be permanently removed from Firestore.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">Yes, Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}
