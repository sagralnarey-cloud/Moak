
"use client";

import Image from "next/image";
import type { Match } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface MatchCardProps {
  match: Match;
  onSelect: (match: Match) => void;
}

export function MatchCard({ match, onSelect }: MatchCardProps) {
  const isLive = match.status === "LIVE";
  const isFinished = match.status === "FINISHED";

  const getStatusColor = () => {
    switch (match.status) {
      case "LIVE":
        return "text-green-500 animate-pulse";
      case "FINISHED":
        return "text-gray-500";
      case "SCHEDULED":
        return "text-blue-500";
      default:
        return "text-muted-foreground";
    }
  }


  return (
    <Card
      className="hover:bg-muted/50 transition-colors cursor-pointer"
      onClick={() => onSelect(match)}
    >
      <CardContent className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3 w-1/3">
          <Image
            src={match.homeTeam.logo}
            alt={`${match.homeTeam.name} logo`}
            width={24}
            height={24}
            className="h-6 w-6"
            data-ai-hint="team logo"
          />
          <span className="font-medium truncate">{match.homeTeam.name}</span>
        </div>

        <div className="flex flex-col items-center justify-center text-center w-1/3">
          {match.status === 'SCHEDULED' ? (
            <div className="text-sm font-bold text-muted-foreground">{match.time}</div>
          ) : (
            <div className="text-xl font-bold">
              {match.homeScore} - {match.awayScore}
            </div>
          )}

          <div
            className={cn(
              "text-xs font-semibold uppercase mt-1",
              getStatusColor()
            )}
          >
            {isLive ? match.time : match.status}
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 w-1/3">
          <span className="font-medium truncate text-right">{match.awayTeam.name}</span>
          <Image
            src={match.awayTeam.logo}
            alt={`${match.awayTeam.name} logo`}
            width={24}
            height={24}
            className="h-6 w-6"
            data-ai-hint="team logo"
          />
        </div>
      </CardContent>
    </Card>
  );
}
