
"use client";

import React, { createContext, useState, ReactNode } from "react";

interface DeveloperContextType {
  isDeveloperMode: boolean;
  enableDeveloperMode: () => void;
  disableDeveloperMode: () => void;
}

export const DeveloperContext = createContext<DeveloperContextType | undefined>(
  undefined
);

export function DeveloperProvider({ children }: { children: ReactNode }) {
  const [isDeveloperMode, setIsDeveloperMode] = useState(false);

  const enableDeveloperMode = () => {
    setIsDeveloperMode(true);
  };

  const disableDeveloperMode = () => {
    setIsDeveloperMode(false);
  };

  const value = {
    isDeveloperMode,
    enableDeveloperMode,
    disableDeveloperMode,
  };

  return (
    <DeveloperContext.Provider value={value}>
      {children}
    </DeveloperContext.Provider>
  );
}
