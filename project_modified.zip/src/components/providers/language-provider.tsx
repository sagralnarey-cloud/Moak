
"use client";

import React, { createContext, useState, useEffect, ReactNode } from "react";

const LANGUAGE_KEY = "userLanguage";

type Language = "en" | "ar" | "fr";

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
}

export const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined
);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");
  const [isClient, setIsClient] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsClient(true);
    try {
      const storedValue = localStorage.getItem(LANGUAGE_KEY) as Language | null;
      if (storedValue && ["en", "ar", "fr"].includes(storedValue)) {
        setLanguage(storedValue);
      } else {
        const browserLang = navigator.language.split('-')[0];
        if (browserLang === 'ar') {
            setLanguage('ar');
        } else if (browserLang === 'fr') {
            setLanguage('fr');
        }
      }
    } catch (error) {
      console.error("Could not access localStorage", error);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    if(isClient) {
        try {
            localStorage.setItem(LANGUAGE_KEY, language);
            document.documentElement.lang = language;
            document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
        } catch (error) {
            console.error("Could not set item in localStorage", error);
        }
    }
  }, [language, isClient]);

  const value = {
    language,
    setLanguage,
  };

  if (!isLoaded) {
    return null; // Or a loading spinner
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}
