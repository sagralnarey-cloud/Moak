
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";
import { FavoritesManager } from "./favorites-manager";

interface EmptyStateProps {
  title: string;
  description: string;
}

export function EmptyState({ title, description }: EmptyStateProps) {
  return (
    <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm h-full">
      <div className="flex flex-col items-center gap-2 text-center p-4">
        <h3 className="text-2xl font-bold tracking-tight">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
        <FavoritesManager>
          <Button className="mt-4">
            <Star className="mr-2 h-4 w-4" /> Select Favorites
          </Button>
        </FavoritesManager>
      </div>
    </div>
  );
}
