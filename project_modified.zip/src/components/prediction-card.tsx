
"use client";

import Image from "next/image";
import Link from "next/link";
import { useState, useEffect } from "react";
import type { Match, Prediction } from "@/types";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { submitPrediction } from "@/lib/predictions";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface PredictionCardProps {
  match: Match;
}

export function PredictionCard({ match }: PredictionCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [homeScore, setHomeScore] = useState<string>(match.userPrediction?.homeScore?.toString() ?? "");
  const [awayScore, setAwayScore] = useState<string>(match.userPrediction?.awayScore?.toString() ?? "");
  const [isLoading, setIsLoading] = useState(false);
  
  const isPredictionLocked = match.status !== 'SCHEDULED' || new Date(match.date || 0) < new Date();
  const hasPredicted = !!match.userPrediction;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
        toast({ variant: "destructive", title: "Authentication Required", description: "Please sign in to submit a prediction."});
        return;
    }
    if (homeScore === "" || awayScore === "") {
        toast({ variant: "destructive", title: "Invalid Input", description: "Please enter a score for both teams."});
        return;
    }

    setIsLoading(true);
    const result = await submitPrediction(user.uid, match.id, parseInt(homeScore), parseInt(awayScore));
    setIsLoading(false);

    toast({
        variant: result.success ? "default" : "destructive",
        title: result.success ? "Prediction Submitted!" : "Submission Failed",
        description: result.message,
    });
  };

  const renderPredictionState = () => {
    if (isPredictionLocked) {
        return (
             <div className="text-center py-4">
                <p className="font-semibold text-destructive">Prediction Closed</p>
                {hasPredicted && (
                    <p className="text-sm text-muted-foreground mt-1">Your prediction: {match.userPrediction?.homeScore} - {match.userPrediction?.awayScore}</p>
                )}
             </div>
        );
    }

    if (hasPredicted) {
        return (
            <div className="text-center py-4">
                <p className="font-semibold text-green-600">Prediction Saved!</p>
                <p className="text-lg font-bold">{match.userPrediction?.homeScore} - {match.userPrediction?.awayScore}</p>
                <p className="text-xs text-muted-foreground mt-1">You can change your prediction until kickoff.</p>
            </div>
        )
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="flex items-center justify-center gap-4">
                <Input type="number" min="0" max="99" className="w-20 text-center font-bold text-lg" placeholder="0" value={homeScore} onChange={e => setHomeScore(e.target.value)} disabled={isLoading} />
                <span className="font-bold">-</span>
                <Input type="number" min="0" max="99" className="w-20 text-center font-bold text-lg" placeholder="0" value={awayScore} onChange={e => setAwayScore(e.target.value)} disabled={isLoading} />
            </div>
            <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading && <Loader2 className="animate-spin" />}
                {hasPredicted ? "Update Prediction" : "Submit Prediction"}
            </Button>
      </form>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-center text-base">{match.competition.name}</CardTitle>
        <CardDescription className="text-center">
            {match.time} - {new Date(match.date || '').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex justify-around items-center mb-4">
          <div className="flex flex-col items-center gap-2 w-1/3 text-center">
            <Image
              src={match.homeTeam.logo}
              alt={match.homeTeam.name}
              width={48}
              height={48}
              className="h-12 w-12"
              data-ai-hint="team logo"
            />
            <h3 className="font-bold text-md">{match.homeTeam.name}</h3>
          </div>
          <div className="text-2xl font-bold w-1/3 text-center">VS</div>
          <div className="flex flex-col items-center gap-2 w-1/3 text-center">
            <Image
              src={match.awayTeam.logo}
              alt={match.awayTeam.name}
              width={48}
              height={48}
              className="h-12 w-12"
              data-ai-hint="team logo"
            />
            <h3 className="font-bold text-md">{match.awayTeam.name}</h3>
          </div>
        </div>
        
        {renderPredictionState()}

      </CardContent>
       {hasPredicted && match.userPrediction?.points !== undefined && (
          <CardFooter className="flex-col !pb-4 !pt-0">
                <div className={cn(
                    "w-full text-center p-2 rounded-md font-semibold", 
                    match.userPrediction.points > 0 ? "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300" : "bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300"
                )}>
                   {match.userPrediction.points > 0 ? `You earned ${match.userPrediction.points} points!` : "No points this time."}
                </div>
           </CardFooter>
        )}
    </Card>
  );
}
