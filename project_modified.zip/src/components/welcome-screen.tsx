
"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { FavoritesManager } from "./favorites-manager";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { ScrollArea } from "./ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { LanguageToggle } from "./language-toggle";
import { ThemeToggle } from "./theme-toggle";

const WELCOME_SCREEN_KEY = "hasSeenWelcomeScreen";

export function WelcomeScreen() {
  const [isOpen, setIsOpen] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const { language } = useLanguage();
  const t = translations[language];

  useEffect(() => {
    setIsClient(true);
    try {
      const hasSeen = localStorage.getItem(WELCOME_SCREEN_KEY);
      if (!hasSeen) {
        setIsOpen(true);
      }
    } catch (error) {
      console.error("Could not access localStorage", error);
    }
  }, []);

  const handleClose = () => {
    try {
      localStorage.setItem(WELCOME_SCREEN_KEY, "true");
      setIsOpen(false);
    } catch (error) {
      console.error("Could not set item in localStorage", error);
    }
  };

  if (!isClient || !isOpen) {
    return null;
  }

  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex flex-col bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
        "transition-opacity duration-500",
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
    >
        <ScrollArea className="flex-1">
            <div className="container max-w-2xl py-8 md:py-12">
                <div className="text-center mb-8">
                    <h1 className="font-extrabold text-4xl tracking-tight text-primary mb-2 font-serif">
                        {language === 'ar' ? t.welcome.title : (language === 'fr' ? translations.fr.welcome.title : t.welcomeAr.title)}
                    </h1>
                    <p className="text-muted-foreground">
                        {language === 'ar' ? t.welcome.subtitle : (language === 'fr' ? translations.fr.welcome.subtitle : t.welcomeAr.subtitle)}
                    </p>
                </div>
                
                 <Card className="mb-4">
                    <CardHeader>
                        <CardTitle>Appearance & Language</CardTitle>
                        <CardDescription>Customize the look and feel of the app.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                       <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Theme</span>
                            <ThemeToggle />
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Language</span>
                           <LanguageToggle />
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Personalize Your Experience</CardTitle>
                        <CardDescription>Select your favorite competitions and teams to get started.</CardDescription>
                    </CardHeader>
                    <CardContent>
                         <FavoritesManager showTrigger={false} />
                    </CardContent>
                </Card>

            </div>
        </ScrollArea>
        <div className="container max-w-2xl p-4 border-t bg-background">
             <Button size="lg" className="w-full" onClick={handleClose}>
                {`${translations.en.welcome.button} / ${translations.ar.welcome.button} / ${translations.fr.welcome.button}`}
            </Button>
        </div>
    </div>
  );
}
