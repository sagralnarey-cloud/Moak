
"use client";

import { X, Search as SearchIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex flex-col bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60",
        "transition-opacity duration-300 ease-in-out",
        isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
    >
      <div className="container max-w-screen-2xl">
        <div className="flex h-14 items-center gap-2">
          <Input 
            placeholder="Search teams, competitions, or matches..." 
            className="h-10 text-base"
          />
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6" />
            <span className="sr-only">Close search</span>
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        <div className="container max-w-screen-2xl py-4">
           {/* Placeholder for search results */}
           <div className="flex flex-col items-center justify-center text-center text-muted-foreground pt-16">
              <SearchIcon className="h-12 w-12 mb-4" />
              <p>Search for your favorite teams and competitions.</p>
            </div>
        </div>
      </div>
    </div>
  );
}
