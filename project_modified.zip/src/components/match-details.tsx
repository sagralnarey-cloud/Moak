
import Image from "next/image";
import type { Match } from "@/types";
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from "@/components/ui/dialog";

interface MatchDetailsProps {
  match: Match;
}

export function MatchDetails({ match }: MatchDetailsProps) {
  return (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle className="text-center text-xl">
          {match.competition.name}
        </DialogTitle>
        <DialogDescription className="text-center">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </DialogDescription>
      </DialogHeader>

      <div className="flex justify-around items-center py-8">
        <div className="flex flex-col items-center gap-2 w-1/3 text-center">
          <Image
            src={match.homeTeam.logo}
            alt={match.homeTeam.name}
            width={64}
            height={64}
            className="h-16 w-16"
            data-ai-hint="team logo"
          />
          <h3 className="font-bold text-lg">{match.homeTeam.name}</h3>
        </div>
        <div className="text-4xl font-extrabold w-1/3 text-center">
          {match.status === "SCHEDULED"
            ? match.time
            : `${match.homeScore} - ${match.awayScore}`}
        </div>
        <div className="flex flex-col items-center gap-2 w-1/3 text-center">
          <Image
            src={match.awayTeam.logo}
            alt={match.awayTeam.name}
            width={64}
            height={64}
            className="h-16 w-16"
            data-ai-hint="team logo"
          />
          <h3 className="font-bold text-lg">{match.awayTeam.name}</h3>
        </div>
      </div>
      
      <div className="text-center text-muted-foreground font-semibold">
        {match.status === "LIVE" && `${match.time}' | Live`}
        {match.status === "FINISHED" && "Full Time"}
        {match.status === "SCHEDULED" && "Scheduled"}
      </div>

    </DialogContent>
  );
}
