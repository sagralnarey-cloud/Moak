
"use client";

import { useEffect, useState, type ReactNode } from "react";
import { Loader2, Shield, Trophy } from "lucide-react";
import { getCompetitions, getTeams } from "@/lib/api";
import { useFavorites } from "@/hooks/use-favorites";
import type { Competition, Team } from "@/types";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

interface FavoritesListProps {
    competitions: Competition[];
    teams: Team[];
}

function FavoritesList({ competitions, teams}: FavoritesListProps) {
  const { isFavorite, toggleFavorite } = useFavorites();
  
  return (
    <ScrollArea className="h-72">
        <div className="grid gap-4 py-4">
          <h3 className="font-semibold flex items-center gap-2"><Trophy className="h-4 w-4" /> Competitions</h3>
          {competitions.map((comp) => (
            <div key={comp.id} className="flex items-center space-x-2">
              <Checkbox
                id={`comp-${comp.id}`}
                checked={isFavorite(comp.id, "competitions")}
                onCheckedChange={() => toggleFavorite(comp.id, "competitions")}
              />
              <label
                htmlFor={`comp-${comp.id}`}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                {comp.name}
              </label>
            </div>
          ))}
          <Separator className="my-4" />
          <h3 className="font-semibold flex items-center gap-2"><Shield className="h-4 w-4" /> Teams</h3>
          {teams.map((team) => (
            <div key={team.id} className="flex items-center space-x-2">
              <Checkbox
                id={`team-${team.id}`}
                checked={isFavorite(team.id, "teams")}
                onCheckedChange={() => toggleFavorite(team.id, "teams")}
              />
              <label
                htmlFor={`team-${team.id}`}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                {team.name}
              </label>
            </div>
          ))}
        </div>
      </ScrollArea>
  )
}


interface FavoritesManagerProps {
    children?: ReactNode;
    showTrigger?: boolean;
}

export function FavoritesManager({ children, showTrigger = true }: FavoritesManagerProps) {
  const [competitions, setCompetitions] = useState<Competition[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      const [comps, fetchedTeams] = await Promise.all([
        getCompetitions(),
        getTeams(),
      ]);
      setCompetitions(comps);
      setTeams(fetchedTeams);
      setIsLoading(false);
    };
    fetchData();
  }, []);

  const content = isLoading ? (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    ) : (
      <FavoritesList competitions={competitions} teams={teams} />
    );

  if (!showTrigger) {
    return content;
  }

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Manage Favorites</DialogTitle>
          <DialogDescription>
            Select your favorite competitions and teams to personalize your
            experience.
          </DialogDescription>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
}
