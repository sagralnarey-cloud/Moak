
"use client";

import { useState, useMemo, useCallback, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { format, eachDayOfInterval } from "date-fns";
import { ar, fr, enUS } from "date-fns/locale";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MatchCard } from "@/components/match-card";
import { EmptyState } from "@/components/empty-state";
import { useFavorites } from "@/hooks/use-favorites";
import type { Match } from "@/types";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { Card, CardContent } from "@/components/ui/card";


interface GroupedMatches {
  [date: string]: Match[];
}

interface ResultsTabsProps {
    matches: Match[];
    dates: string[];
}

export default function ResultsTabs({ matches: initialMatches, dates }: ResultsTabsProps) {
  const [matches, setMatches] = useState<Match[]>(initialMatches);
  const { favoriteTeams, favoriteCompetitions } = useFavorites();
  const router = useRouter();
  const { language } = useLanguage();
  const t = translations[language];
  const locale = language === 'ar' ? ar : (language === 'fr' ? fr : enUS);

  useEffect(() => {
    setMatches(initialMatches);
  }, [initialMatches]);

  const allDatesInRange = useMemo(() => dates.map(d => new Date(d)), [dates]);
  
  const translateMatches = useCallback((matchList: Match[]) => {
    const competitionsMap = t.competitions as Record<string, string>;
    const teamsMap = t.teams as Record<string, string>;

    return matchList.map(match => ({
      ...match,
       competition: {
          ...match.competition,
          name: competitionsMap[match.competition.name] || match.competition.name
      },
      homeTeam: {
          ...match.homeTeam,
          name: teamsMap[match.homeTeam.name] || match.homeTeam.name
      },
      awayTeam: {
          ...match.awayTeam,
          name: teamsMap[match.awayTeam.name] || match.awayTeam.name
      },
    }))
  }, [t.competitions, t.teams]);
  
  const groupMatchesByDate = (matchList: Match[]): GroupedMatches => {
    return matchList.reduce((acc, match) => {
        if (!match.date) return acc;
        const dateKey = format(new Date(match.date), 'yyyy-MM-dd');
        if (!acc[dateKey]) {
            acc[dateKey] = [];
        }
        acc[dateKey].push(match);
        return acc;
    }, {} as GroupedMatches);
  };

  const myResults = useMemo(() => {
    if (favoriteTeams.length === 0) return {};
    const filtered = matches.filter(match => 
        favoriteTeams.includes(match.homeTeam.id) || 
        favoriteTeams.includes(match.awayTeam.id)
    );
    return groupMatchesByDate(translateMatches(filtered));
  }, [matches, favoriteTeams, translateMatches]);

  const allResults = useMemo(() => {
    if (favoriteCompetitions.length === 0) return {};
    const filtered = matches.filter(match => 
        favoriteCompetitions.includes(match.competition.id)
    );
    return groupMatchesByDate(translateMatches(filtered));
  }, [matches, favoriteCompetitions, translateMatches]);


  const handleMatchSelect = (match: Match) => {
    router.push(`/match/${match.id}`);
  };

  const renderMatchList = (groupedMatches: GroupedMatches, hasFavorites: boolean, emptyState: React.ReactNode) => {
    
    if (!hasFavorites) {
        return <div className="h-64 flex items-center justify-center">{emptyState}</div>;
    }

    const hasAnyMatches = Object.values(groupedMatches).some(day => day.length > 0);
    if (!hasAnyMatches) {
       return <div className="h-64 flex items-center justify-center">{emptyState}</div>;
    }

    return (
      <div className="space-y-4">
        {allDatesInRange.map((date) => {
            const dateKey = format(date, 'yyyy-MM-dd');
            const dailyMatches = groupedMatches[dateKey] || [];
            
            if (dailyMatches.length === 0) return null;

            return (
               <div key={dateKey} className="space-y-2">
                 <h3 className="text-sm font-semibold tracking-tight text-muted-foreground p-2 border-b">
                     {format(date, "eeee, d MMMM yyyy", { locale })}
                </h3>
                {dailyMatches.length > 0 ? (
                    dailyMatches.map((match) => (
                        <MatchCard key={match.id} match={match} onSelect={handleMatchSelect} />
                    ))
                ) : (
                    <Card className="border-dashed">
                        <CardContent className="p-4 text-center text-muted-foreground">
                            <p>{language === 'ar' ? 'لا توجد مباريات مجدولة لهذا اليوم.' : (language === 'fr' ? 'Aucun match prévu pour ce jour.' : 'No matches scheduled for this day.')}</p>
                        </CardContent>
                    </Card>
                )}
               </div>
            )
        })}
      </div>
    );
  };

  return (
    <div className="p-4">
      <Tabs defaultValue="my-results" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="my-results">{t.nav.Favorites} {t.nav.Results}</TabsTrigger>
          <TabsTrigger value="all-results">{t.nav.Competitions} {t.nav.Results}</TabsTrigger>
        </TabsList>
        <TabsContent value="my-results" className="pt-4">
          {renderMatchList(myResults, favoriteTeams.length > 0,
            <EmptyState 
              title="No favorite teams selected"
              description="Add your favorite teams to see their matches here."
            />
          )}
        </TabsContent>
        <TabsContent value="all-results" className="pt-4">
          {renderMatchList(allResults, favoriteCompetitions.length > 0,
            <EmptyState
              title="No favorite competitions selected"
              description="Add your favorite competitions to see all their matches here."
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
