
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Star, Settings, Newspaper, Trophy, ArrowLeft, Heart, Search, LogIn, LogOut } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Icons } from "@/components/icons";
import { SearchOverlay } from "@/components/search-overlay";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";

export default function Header() {
  const pathname = usePathname();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { language } = useLanguage();
  const t = translations[language];

  const getTitle = () => {
    return "نبض الكرة";
  };
  
  const showBackButton = pathname.startsWith('/predictions/') || pathname.startsWith('/match/');
  const backButtonLink = pathname.startsWith('/match/') ? '/' : '/competitions';
  

  const showSearchButton = !showBackButton;

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 max-w-screen-2xl items-center">
          <div className="flex flex-1 items-center gap-2">
            {showBackButton ? (
              <Button asChild variant="ghost" size="icon" className="mr-2">
                <Link href={backButtonLink}>
                  <ArrowLeft />
                </Link>
              </Button>
            ) : (
              <Link href="/" className="mr-2 flex items-center space-x-2">
                <Icons.logo className="h-6 w-6 text-primary" />
              </Link>
            )}

            <h1 className="text-xl font-bold">
              {getTitle()}
            </h1>
          </div>
          
          <div className="flex items-center gap-2">
            {showSearchButton && (
              <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(true)}>
                  <Search />
                  <span className="sr-only">Search</span>
                </Button>
            )}
          </div>
        </div>
      </header>
      <SearchOverlay isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
    </>
  );
}
