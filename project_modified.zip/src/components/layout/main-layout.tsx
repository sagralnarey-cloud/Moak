
"use client";

import { Home, Trophy, Newspaper, Settings, Sparkles, Star } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import Header from "./header";
import { useLanguage } from "@/hooks/use-language";
import { translations } from "@/data/translations";

const navItems = [
  { href: "/more", label: "More", icon: Settings },
  { href: "/predictions", label: "Predictions", icon: Sparkles },
  { href: "/competitions", label: "Competitions", icon: Trophy },
  { href: "/news", label: "News", icon: Newspaper },
  { href: "/favorites", label: "Favorites", icon: Star },
  { href: "/", label: "Results", icon: Home },
];

export default function MainLayout({ children }: { children: React.ReactNode; }) {
  const pathname = usePathname();
  const { language } = useLanguage();

  // Hide nav for specific pages
  const hideNav = pathname.startsWith('/predictions/') || pathname.startsWith('/match/');

  const tNav = translations[language].nav;

  if (hideNav) {
    return (
       <div className="flex min-h-screen w-full flex-col">
          <Header />
          <main className="flex flex-1 flex-col">{children}</main>
        </div>
    )
  }

  return (
      <div className="flex min-h-screen w-full flex-col">
        <Header />
        <main className="flex flex-1 flex-col pb-16">{children}</main>
        <nav className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background">
          <div className="container mx-auto grid h-14 max-w-screen-2xl grid-cols-6 items-center px-2">
            {navItems.map(({ href, label, icon: Icon }) => {
              const translatedLabel = tNav[label as keyof typeof tNav];
              return (
                <Link
                  key={href}
                  href={href}
                  className={cn(
                    "flex flex-col items-center justify-center gap-0.5 p-1 text-xs font-medium",
                    pathname === href
                      ? "text-primary"
                      : "text-muted-foreground hover:text-primary"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-[10px]">{translatedLabel}</span>
                </Link>
              )
            })}
          </div>
        </nav>
      </div>
  );
}
